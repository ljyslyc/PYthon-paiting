from pyecharts.charts import Map3D

Map3D().add_schema().render()
