import matplotlib.pyplot as plt
import numpy as np

np.random.seed(19680801)

N = 10
theta = np.linspace(0.0, 2 * np.pi, N, endpoint=False)
radii = 10 * np.random.rand(N)
width = np.pi / 4 * np.random.rand(N)

ax = plt.subplot(111, projection='polar')
bars = ax.bar(theta, radii, width=width, bottom=0.0)
# left indicates where to start
# radii (radius)  indicates the length drawn from the center point to the edge
# width indicates the arc length at the end

# custom the color and opacity
for r, bar in zip(radii, bars):
    bar.set_facecolor(plt.cm.viridis(r / 10.))
    bar.set_alpha(0.5)

plt.show()
