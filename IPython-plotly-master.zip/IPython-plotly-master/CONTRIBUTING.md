Notebooks are now added to a new github pages repository that contains all of plotly's documentation. See the new contributing.md: https://github.com/plotly/documentation/blob/source/Contributing.md
